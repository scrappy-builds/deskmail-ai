# PROGRESS — DeskMail AI build log

> **Claude Code: this file is the single source of truth for "where we are".**
> - Read it first at the start of every session (then `git log` + run the app/tests to confirm).
> - Update it at the end of every stage: tick the stage, note what was done, list TODOs/known
>   issues, and record the exact next step.
> - Keep it accurate — trust it over memory.

---

## Current status
- **Active stage:** _not started_
- **Last session ended:** _—_
- **Exact next step:** Read the pack (`README.md`, `CLAUDE_CODE_PROMPT.md`, `FEATURE_SPEC.md`,
  `Functional3DUK_Brand_Guide.md`, the `design-files/`), write the implementation plan, and confirm
  the plan + stage list with the user before starting Stage 1.

---

## Implementation plan
_(Fill in after planning: chosen versions/libraries, folder structure, key decisions.)_

---

## Stage checklist
Tick only when the stage's tests pass AND the app builds + launches. Then ask the user before moving on.

- [ ] **Stage 1** — Scaffold & shell (secure window, title/command bars, light default + Light/Dark toggle, tokens)
- [ ] **Stage 2** — Layout system + 6 presets + View Settings + persistence
- [ ] **Stage 3** — Full independent message windows (double-click, by ID)
- [ ] **Stage 4** — SQLite + migrations + account wizard + secure credentials + connection tests
- [ ] **Stage 5** — Sync + parsing + offline cache + safe rendering (sanitise, block remote images)
- [ ] **Stage 6** — Search + Compose + Drafts + manual Send + signature insertion
- [ ] **Stage 7** — Calendar + invites + meeting providers
- [ ] **Stage 8** — Added features: per-account signatures · send-later/undo-send · snooze · templates · contacts · Today agenda
- [ ] **Stage 9** — Local MCP server (safe tools; Claude Desktop connector config)
- [ ] **Stage 10** — Packaging (installer) + local backup + USB/portable mode
- [ ] **Stage 11** — Hardening + error/empty/loading states + docs
- [ ] **Stage 12** — Final review (verify every feature/security item/MCP tool; fix gaps)

---

## Per-stage notes
### Stage 1
- Done:
- Tests:
- Known issues / TODO:
- Next step:

_(Add a block like the above for each stage as you go.)_

---

## Final review checklist (complete in Stage 12)
- [ ] Every MVP feature present and working
- [ ] All six layout presets + persistence
- [ ] Full independent message windows
- [ ] Calendar + invites + meeting providers
- [ ] All six added features
- [ ] All MCP tools present; forbidden actions impossible
- [ ] Security requirements all met (sanitise, block remote images, secure creds, no Node in renderer, no auto-open, manual send)
- [ ] Installer builds; backup/restore + portable mode verified
- [ ] Light default + easy Light/Dark toggle; styling matches the Style Guide; copy in Jamie's voice
- [ ] `npm test` + `npm run test:e2e` green; app builds and launches clean
